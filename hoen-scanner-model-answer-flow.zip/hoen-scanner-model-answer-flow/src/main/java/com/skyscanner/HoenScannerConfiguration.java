package com.skyscanner;

import io.dropwizard.core.Configuration;

public class HoenScannerConfiguration extends Configuration {

}
